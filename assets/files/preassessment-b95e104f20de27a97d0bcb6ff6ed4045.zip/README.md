## Part 1

Create an HTML page containing your name, graduation year, favorite ice
cream flavor, and favorite party parrot.

For reference: https://cultofthepartyparrot.com/

## Part 2

Answer the 4 JavaScript questions in release.js.

_[Optional, but highly recommended]_: Test your code. Get a head start on the
course's development environment by installating Node.js
[here](https://nodejs.org/en/download/) (follow the instructions for Node 12).
Then, in a terminal with the extracted contents of the pretest files, run
`node preassessment.test.js` to evaluate your `preassessment.js` code. You may
add more test cases if you wish.
